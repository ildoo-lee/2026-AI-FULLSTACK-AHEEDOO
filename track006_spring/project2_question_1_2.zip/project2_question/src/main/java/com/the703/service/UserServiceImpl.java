package com.the703.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.the703.dao.UserMapper;
import com.the703.dto.AuthDto;
import com.the703.dto.AuthUserDto;
import com.the703.dto.UserDto;

@Service
public class UserServiceImpl implements UserService {

	@Autowired UserMapper dao;
	@Autowired @Qualifier("passwordEncoder") PasswordEncoder pwencoder;
	
	@Override
	public int insert(UserDto dto) {
		AuthDto adto = new AuthDto();
		adto.setEmail(dto.getEmail()); 
		adto.setAuth("MEMBER_ROLE");
		dao.insertAuth(adto); 
		
		dto.setBpass(pwencoder.encode(dto.getBpass()));  
		try { dto.setBip(java.net.InetAddress.getLocalHost().getHostAddress()); }
		catch (java.net.UnknownHostException e) { e.printStackTrace(); }
		return dao.insert(dto);
	}

	@Override 
	public String findByEmail(String email) { 
		return dao.findByEmail(email); 
	}
        
	@Override 
	public UserDto findByEmailUserInfo(String email) {
		return dao.findByEmailUserInfo(email); 
	}

	@Override 
	public String findByNickname(String nickname) {  
		return dao.findByNickname(nickname); 
	}

	@Override public AuthUserDto readAuth(String email) {  return null; }
	@Override public UserDto findByUno(int uno) {  return null; }
	@Override public int findLogin(UserDto dto) {  return 0; }
	@Override public void AuthListDto() {}
	@Override public void readAuth(AuthDto dto) {}
}