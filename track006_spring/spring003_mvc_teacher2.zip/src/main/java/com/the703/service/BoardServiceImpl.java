package com.the703.service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.the703.dao.BoardMapper;
import com.the703.dto.BoardDto;

@Service
public class BoardServiceImpl  implements BoardService {
	@Autowired  BoardMapper  dao;  // db����   
	@Override public List<BoardDto> selectAll() { return dao.selectAll(); }

	@Override public int insert(BoardDto dto) {
		try { dto.setBip(InetAddress.getLocalHost().getHostAddress()); }
		catch (UnknownHostException e) { e.printStackTrace(); }
		return dao.insert(dto);
	} 
	@Override public BoardDto detail(int bno) {
		dao.updateHit(bno);      // ��ȸ�� �ø��� ##
		return dao.select(bno);
	} 
	@Override public BoardDto editView(int bno) { return dao.select(bno); }
	
	@Override public int edit(BoardDto dto) { 
		int result = -1;   // ��� �ȸ���
		
		BoardDto find = dao.select( dto.getBno() ); 
		if(find.getBpass().equals( dto.getBpass() )) {  result = dao.update(dto);	}
		
		return result;
	}// ��������� ����
	
	@Override public int delete(BoardDto dto) { 
		int result = -1;   // ��� �ȸ���
		
		BoardDto find = dao.select( dto.getBno() ); 
		if(find.getBpass().equals( dto.getBpass() )) {  result = dao.delete(dto.getBno());	}
		 
		return result;
	}// ��������� ����
}
